<html>
<head>
    <meta charset="utf-8">
    <title>Virtual Proof</title>
    <link rel="stylesheet" href="{{asset('css/pdf.css')}}">
    <style>
        .page-break {
            page-break-after: always;
        }
    </style>
</head>
<body>

<div class="first_page">

</div>

<div class="page-break"></div>
<?php
$email = "hello@printanything.com";
$dir = storage_path() .'\\app\\users\\' . auth()->user()->id . '\\' . $name;
$pub_dir = 'app/users/' . auth()->user()->id . '/' . $name;
chdir($dir);
$file_name =  glob("*.{jpg,gif,png,jpeg,PNG,JPG,JPEG}", GLOB_BRACE);
if ($dir){
$files = File::allFiles($dir);
$i = 0;
foreach ($files as $index => $file){
$i = $i + 1?>
<div class="top">

    <div class="right">
        <img src="{{asset('images/bitmap.png')}}" style="height: 80px">
        <div style="width: 100%"><p style="text-align: right">{{date('Y-m-d')}}</p></div>
        <div style="width: 100%"><p style="text-align: right">{{'VPR/' . date('Y') . '/' . date('m') . '/' . '1'}}</p></div>
    </div>

    <div class="left">
        <img src="{{asset('images/1.png')}}">
    </div>

</div>
<div class="proof">
    <img class="displayed" src="<?php echo asset('storage/' . $pub_dir . $file_name[$index])?>">

</div>
<div class="bottom">
    <div class="left">
        <p>Please kindly review all text, letters, spellings, images and formatting to ensure this virtual proof
            matches your design requirements. Print Anything &trade; Nigeria will not be held liable for any errors
            in production once this virtual proof is approved.</p>
    </div>
    <div class="centre">
        <ul style="list-style: none">
            <li style="text-decoration: underline">Contact Information</li>
            <li><strong>0909-999-9652</strong></li>
            <li><strong style="text-transform: lowercase">{{$email}}</strong></li>
        </ul>
    </div>
    <div class="right">
        <div>
            <ul style="list-style: none">
                <li><A HREF="{{url('/accept/')}}" class="button accept">Accept</A></li>
                <li><A HREF="{{url('/decline/')}}" class="button decline">Decline</A> </li>
            </ul>
            <div class="circle-one">
                <img src="{{asset('img/g4526.png')}}">
                <div class="circle-two">
                    <p style="position: absolute;
    top: 17;
    right: 37;
    font-weight: normal;
    font-size: small;"><?php echo $i ;
                        ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="page-break"></div>
<?php

}
}
?>
<div class="last_page">
    <span class="img-white"></span>
    <div class="last-text">
        <p>We hope you like your designs</p>
        <p>Please kindly refer back with corrections</p>
        <p>as soon as possible</p>
    </div>
</div>

<button onclick="myFunction()" class="buttom no-print">Print</button>

<script>
    page.evaluate(function() {
        [].slice.call(document.querySelectorAll("a[href]")).forEach(function (a) {
            var e = document.createEvent('MouseEvents');
            e.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);

            a.dispatchEvent(e);
            waitforload = true; //for putting some delay to load the page properly
        });
    });

    function myFunction() {
        window.print();
    }

</script>

</body>
</html>